"""Source adapter package."""
