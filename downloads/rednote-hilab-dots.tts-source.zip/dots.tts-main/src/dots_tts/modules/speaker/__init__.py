"""Speaker modules."""
