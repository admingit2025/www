"""Vocoder modules."""
