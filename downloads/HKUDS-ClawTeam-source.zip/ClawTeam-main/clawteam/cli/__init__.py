"""CLI module for clawteam."""
