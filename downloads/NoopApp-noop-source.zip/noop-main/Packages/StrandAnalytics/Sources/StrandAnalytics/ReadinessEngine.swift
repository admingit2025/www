import Foundation
import WhoopStore

/// On-device "Readiness" intelligence.
///
/// Synthesizes a handful of established, non-medical sports-science signals from the daily-metrics
/// history into a single readiness read plus the drivers behind it. Everything here is a pure,
/// deterministic function of the rows you pass in — no networking, no strap commands, no state.
///
/// Signals and their references:
/// - **HRV readiness** — z-score of today's HRV against the personal trailing baseline. A drop of
///   roughly half a standard deviation flags autonomic fatigue (Plews et al. 2013; Buchheit 2014).
/// - **Resting-HR drift** — elevated resting HR vs baseline is a classic overtraining / illness
///   signal (Lamberts et al. 2004).
/// - **Respiratory-rate drift** — a rise in sleeping respiratory rate is an early illness signal.
/// - **Training Stress Balance (ACWR)** — acute (7-day) vs chronic (28-day) strain. The 0.8–1.3
///   band is the "sweet spot"; >1.5 is associated with higher injury risk (Gabbett 2016).
/// - **Training monotony** — mean/SD of daily strain over a week; high monotony (low variety) is
///   associated with higher strain and illness (Foster 1998).
///
/// Not medical advice. These are approximations from a consumer strap; they describe trends in
/// *your own* data, nothing more.
public enum ReadinessEngine {

    // MARK: Output types

    public enum Level: String, Sendable, Equatable {
        case primed       // signals aligned, load supported
        case balanced     // nothing notable either way
        case strained     // one meaningful signal down / load high
        case rundown      // several recovery signals down
        case insufficient // not enough history yet
    }

    public enum Flag: String, Sendable, Equatable {
        case good, neutral, watch, bad
    }

    public struct Signal: Sendable, Equatable {
        public let key: String      // "hrv" | "rhr" | "respRate" | "acwr" | "monotony"
        public let label: String    // short human label
        public let detail: String   // one-line plain-English read
        public let flag: Flag
        public init(key: String, label: String, detail: String, flag: Flag) {
            self.key = key; self.label = label; self.detail = detail; self.flag = flag
        }
    }

    public struct Readiness: Sendable, Equatable {
        public let level: Level
        public let headline: String
        public let summary: String
        public let signals: [Signal]
        /// Acute:chronic workload ratio (nil if not enough strain history).
        public let acwr: Double?
        /// Foster training monotony over the last week (nil if not enough strain history).
        public let monotony: Double?
        public init(level: Level, headline: String, summary: String,
                    signals: [Signal], acwr: Double?, monotony: Double?) {
            self.level = level; self.headline = headline; self.summary = summary
            self.signals = signals; self.acwr = acwr; self.monotony = monotony
        }
    }

    // MARK: Tunables (named so the thresholds are auditable)

    private static let baselineWindow = 30   // days for HRV / RHR / RR baselines
    private static let minBaseline    = 7    // need at least this many baseline nights
    private static let acuteWindow    = 7
    private static let chronicWindow  = 28
    private static let minChronic     = 14   // need at least this much strain history for ACWR

    // MARK: Entry point

    /// Evaluate readiness from daily metrics. `days` may be in any order; the most recent day is
    /// treated as "today" unless `today` (a YYYY-MM-DD string) is given.
    public static func evaluate(days: [DailyMetric], today: String? = nil) -> Readiness {
        let sorted = days.sorted { $0.day < $1.day }
        guard let latest = today.flatMap({ t in sorted.first { $0.day == t } }) ?? sorted.last else {
            return Readiness(level: .insufficient,
                             headline: "Readiness",
                             summary: "Wear the strap for a few nights and your readiness read will appear here.",
                             signals: [], acwr: nil, monotony: nil)
        }
        let history = sorted.filter { $0.day < latest.day }   // everything before today

        var signals: [Signal] = []

        // HRV readiness ------------------------------------------------------
        let hrvSignal = zSignal(
            value: latest.avgHrv,
            baseline: history.suffix(baselineWindow).compactMap { $0.avgHrv },
            key: "hrv", label: "HRV",
            higherIsBetter: true,
            goodText: "above your baseline — well recovered",
            neutralText: "in your normal range",
            watchText: "a touch below baseline",
            badText: "suppressed — a sign of autonomic fatigue")
        if let s = hrvSignal { signals.append(s) }

        // Resting-HR drift ---------------------------------------------------
        let rhrSignal = zSignal(
            value: latest.restingHr.map(Double.init),
            baseline: history.suffix(baselineWindow).compactMap { $0.restingHr.map(Double.init) },
            key: "rhr", label: "Resting HR",
            higherIsBetter: false,
            goodText: "at or below baseline",
            neutralText: "in your normal range",
            watchText: "running a little high",
            badText: "elevated — overtraining or illness can do this")
        if let s = rhrSignal { signals.append(s) }

        // Respiratory-rate drift (illness early signal) ----------------------
        if let rr = latest.respRateBpm {
            let base = history.suffix(baselineWindow).compactMap { $0.respRateBpm }
            if base.count >= minBaseline, let sd = sampleSD(base), sd > 0 {
                let z = (rr - mean(base)!) / sd
                if z >= 1.5 {
                    signals.append(Signal(key: "respRate", label: "Respiratory rate",
                        detail: "up vs baseline — sometimes an early sign of getting sick", flag: .bad))
                } else if z >= 1.0 {
                    signals.append(Signal(key: "respRate", label: "Respiratory rate",
                        detail: "slightly raised vs baseline", flag: .watch))
                }
            }
        }

        // Training Stress Balance (ACWR) + monotony --------------------------
        let strainSeries = sorted.compactMap { $0.strain }
        var acwr: Double? = nil
        var monotony: Double? = nil
        if strainSeries.count >= minChronic {
            let acute = mean(Array(strainSeries.suffix(acuteWindow)))!
            let chronic = mean(Array(strainSeries.suffix(chronicWindow)))!
            if chronic > 0 {
                let ratio = acute / chronic
                acwr = ratio
                signals.append(acwrSignal(ratio))
            }
            // Foster monotony over the last week of strain.
            let week = Array(strainSeries.suffix(acuteWindow))
            if week.count >= 4, let sd = sampleSD(week), sd > 0, let m = mean(week) {
                let mono = m / sd
                monotony = mono
                if mono >= 2.0 {
                    signals.append(Signal(key: "monotony", label: "Training variety",
                        detail: "low — similar strain every day raises strain/illness risk", flag: .watch))
                }
            }
        }

        let (level, headline, summary) = synthesize(signals: signals,
                                                    hasHistory: !history.isEmpty || acwr != nil)
        return Readiness(level: level, headline: headline, summary: summary,
                         signals: signals, acwr: acwr, monotony: monotony)
    }

    // MARK: Signal builders

    /// Build a z-score signal for a metric where the baseline is the trailing window.
    private static func zSignal(value: Double?, baseline: [Double],
                                key: String, label: String, higherIsBetter: Bool,
                                goodText: String, neutralText: String,
                                watchText: String, badText: String) -> Signal? {
        guard let v = value, baseline.count >= minBaseline,
              let m = mean(baseline), let sd = sampleSD(baseline), sd > 0 else { return nil }
        // Orient z so positive always means "better".
        let z = (higherIsBetter ? (v - m) : (m - v)) / sd
        let flag: Flag
        let text: String
        switch z {
        case 0.5...:        flag = .good;    text = goodText
        case -0.5..<0.5:    flag = .neutral; text = neutralText
        case -1.0 ..< -0.5: flag = .watch;   text = watchText
        default:            flag = .bad;     text = badText
        }
        return Signal(key: key, label: label, detail: text, flag: flag)
    }

    private static func acwrSignal(_ ratio: Double) -> Signal {
        let pct = String(format: "%.2f", ratio)
        switch ratio {
        case ..<0.8:
            return Signal(key: "acwr", label: "Training load",
                detail: "ramping down (acute:chronic \(pct)) — room to build", flag: .watch)
        case 0.8..<1.3:
            return Signal(key: "acwr", label: "Training load",
                detail: "in the sweet spot (acute:chronic \(pct))", flag: .good)
        case 1.3..<1.5:
            return Signal(key: "acwr", label: "Training load",
                detail: "building fast (acute:chronic \(pct)) — watch fatigue", flag: .watch)
        default:
            return Signal(key: "acwr", label: "Training load",
                detail: "spiking (acute:chronic \(pct)) — higher injury risk", flag: .bad)
        }
    }

    // MARK: Synthesis

    private static func synthesize(signals: [Signal], hasHistory: Bool) -> (Level, String, String) {
        guard hasHistory, !signals.isEmpty else {
            return (.insufficient, "Readiness",
                    "A few more nights of data and your readiness read will sharpen.")
        }
        let bad = signals.filter { $0.flag == .bad }
        let watch = signals.filter { $0.flag == .watch }
        let good = signals.filter { $0.flag == .good }
        let recoveryDown = signals.contains { ["hrv", "rhr", "respRate"].contains($0.key) && ($0.flag == .bad) }
        let loadHigh = signals.contains { $0.key == "acwr" && $0.flag == .bad }

        if bad.count >= 2 || (recoveryDown && loadHigh) {
            return (.rundown, "Run down",
                    "Several signals are down at once. Treat today as recovery — easy movement, real sleep tonight.")
        }
        if recoveryDown || loadHigh || bad.count >= 1 {
            return (.strained, "Strained",
                    "One of your signals is flagging. You can train, but keep it controlled and bank the recovery.")
        }
        if good.count >= 2 && watch.isEmpty {
            return (.primed, "Primed",
                    "Your signals are aligned and your load is supported. A harder session is well backed today.")
        }
        return (.balanced, "Balanced",
                "Nothing's flagging. Train to feel — your body's holding steady.")
    }

    // MARK: Stats helpers

    static func mean(_ xs: [Double]) -> Double? {
        xs.isEmpty ? nil : xs.reduce(0, +) / Double(xs.count)
    }

    /// Sample standard deviation (n-1). nil for fewer than 2 points.
    static func sampleSD(_ xs: [Double]) -> Double? {
        guard xs.count >= 2, let m = mean(xs) else { return nil }
        let ss = xs.reduce(0) { $0 + ($1 - m) * ($1 - m) }
        return (ss / Double(xs.count - 1)).squareRoot()
    }
}
