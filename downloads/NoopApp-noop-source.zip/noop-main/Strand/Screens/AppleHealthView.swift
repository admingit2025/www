import SwiftUI
import StrandDesign
import WhoopStore
import Foundation

// MARK: - Apple Health (per-source page) — locked component system
//
// Vitaltrends-style, instrument-grade, uniform. ONE range control at the top
// (SegmentedPillControl), a LazyVGrid of fixed-height StatTiles (every metric the
// same 104pt tall), then ChartCard sections — Heart & Vitals, Activity & Energy,
// Body Composition, Sleep — each chart the same height with an avg/min/max footer.
//
// Everything reads from the "apple-health" source. ALL history is loaded once; the
// range control simply windows it client-side, RELATIVE TO THE LATEST data point
// (not "now"). Per the data contract a series may be SPARSE (weight/body-fat are
// weekly): if the selected window holds ≥1 point we SHOW THAT WINDOW (so W/M/3M stay
// visibly distinct); only when it holds ZERO points do we auto-expand to the smallest
// larger range that does. Tile heroes show the LATEST point with "as of <date>".

struct AppleHealthView: View {
    @EnvironmentObject var repo: Repository

    /// Optional pre-seeded data for previews; when set, the async store load is
    /// skipped (store-backed reads can't be seeded in a preview). Production leaves
    /// this nil and loads from the repository in `.task`.
    private let previewData: PreviewData?

    init() { self.previewData = nil }
    fileprivate init(previewData: PreviewData) { self.previewData = previewData }

    // Loaded state.
    @State private var loaded = false
    @State private var appleRows: [AppleDaily] = []
    @State private var workoutCount = 0

    // Raw series (day, value) keyed by metric — ALL history, ascending by day.
    @State private var series: [String: [(day: String, value: Double)]] = [:]

    // The active range window. The data goes back years — never hard-cap.
    @State private var range: RangeWindow = .quarter

    /// Memoized per-metric resolved window. Resolving a key (effective range +
    /// trimmed rows) re-slices the full multi-year series and, on auto-widen, slices
    /// it once per candidate range. The view body asks for the same key many times
    /// per render (every StatTile, every ChartCard, plus rangeNote/rangeSummary), and
    /// SwiftUI re-evaluates the body on hover / animation / 1Hz HR ticks. The inputs
    /// (`series`, `range`) only change on load or pill tap, so we compute once and
    /// cache, recomputing via .onChange(of:) when an input actually changes.
    @State private var windowCache: [String: ResolvedSeries] = [:]

    /// Memoized per-day rows trimmed to the active window. Read by both
    /// `rangeSummaryCaption` and `spanSubtitle` every render; depends only on
    /// `appleRows` + `range`, so it's cached alongside `windowCache`.
    @State private var windowedRowsCache: [AppleDaily] = []

    /// A key's resolved (possibly auto-widened) window: the effective range plus the
    /// rows trimmed to it.
    private struct ResolvedSeries {
        var effective: RangeWindow
        var rows: [(day: String, value: Double)]
    }

    // The series keys this page pulls from the apple-health source.
    private static let seriesKeys = [
        "steps", "active_kcal", "vo2max",
        "resting_hr", "hrv", "spo2", "resp_rate", "asleep_min",
        "weight", "body_fat", "lean_mass", "bmi"
    ]

    // yyyy-MM-dd → Date (en_US_POSIX / UTC), per the project's date contract.
    private static let dayParser: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone(identifier: "UTC")
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()

    private static let spanFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "d MMM yyyy"
        return f
    }()

    private static let asOfFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "d MMM"
        return f
    }()

    private func date(_ day: String) -> Date? { Self.dayParser.date(from: day) }

    // MARK: - Range control (W / M / 3M / 6M / 1Y / ALL) — the ONE pill control.

    enum RangeWindow: String, CaseIterable, Identifiable {
        case week, month, quarter, half, year, all
        var id: String { rawValue }
        var label: String {
            switch self {
            case .week:    return "W"
            case .month:   return "M"
            case .quarter: return "3M"
            case .half:    return "6M"
            case .year:    return "1Y"
            case .all:     return "ALL"
            }
        }
        /// Number of trailing days; nil = everything.
        var days: Int? {
            switch self {
            case .week:    return 7
            case .month:   return 30
            case .quarter: return 90
            case .half:    return 180
            case .year:    return 365
            case .all:     return nil
            }
        }
        var caption: String {
            switch self {
            case .week:    return "7 DAYS"
            case .month:   return "30 DAYS"
            case .quarter: return "90 DAYS"
            case .half:    return "180 DAYS"
            case .year:    return "365 DAYS"
            case .all:     return "ALL TIME"
            }
        }
        var name: String {
            switch self {
            case .week:    return "week"
            case .month:   return "month"
            case .quarter: return "3 months"
            case .half:    return "6 months"
            case .year:    return "year"
            case .all:     return "all history"
            }
        }
        /// This range plus every LARGER range, ascending — the auto-expand search
        /// order when the selected window holds zero points.
        var widening: [RangeWindow] {
            let order: [RangeWindow] = [.week, .month, .quarter, .half, .year, .all]
            guard let i = order.firstIndex(of: self) else { return [.all] }
            return Array(order[i...])
        }
    }

    var body: some View {
        ScreenScaffold(title: "Apple Health", subtitle: spanSubtitle) {
            if loaded && !hasAnyData {
                ComingSoon(what: "Nothing imported yet. On an iPhone: Health app, tap your photo, Export All Health Data, then import the .zip here in Data Sources.")
            } else if !loaded {
                loadingState
            } else {
                VStack(alignment: .leading, spacing: NoopMetrics.sectionGap) {
                    rangeControl
                    tileGrid
                    heartSection
                    activitySection
                    bodySection
                    sleepSection
                }
            }
        }
        .task { await load() }
        .onChange(of: range) { _ in rebuildWindowCache() }
    }

    /// Rebuild the per-metric resolved-window cache from scratch. Called once after
    /// load and again whenever `range` changes — never inside the render path.
    private func rebuildWindowCache() {
        var cache: [String: ResolvedSeries] = [:]
        cache.reserveCapacity(Self.seriesKeys.count)
        for key in Self.seriesKeys {
            let eff = computeEffectiveRange(key)
            cache[key] = ResolvedSeries(effective: eff, rows: slice(key, eff))
        }
        windowCache = cache
        windowedRowsCache = computeWindowedRows()
    }

    /// True if ANY series or per-day row holds data (drives the empty state).
    private var hasAnyData: Bool {
        if !appleRows.isEmpty { return true }
        return series.values.contains { !$0.isEmpty }
    }

    // MARK: - Load

    private func load() async {
        // Previews inject data directly (store-backed reads can't be seeded).
        if let pd = previewData {
            appleRows = pd.rows.sorted { $0.day < $1.day }
            workoutCount = pd.workoutCount
            series = pd.series
            rebuildWindowCache()
            loaded = true
            return
        }

        async let rows = repo.appleDailyRows()
        async let workouts = repo.workoutRows()

        var fetched: [String: [(day: String, value: Double)]] = [:]
        for key in Self.seriesKeys {
            fetched[key] = await repo.series(key: key, source: "apple-health")
        }

        let loadedRows = await rows
        let appleWorkouts = await workouts.filter { $0.source == "apple_health" || $0.source == "apple-health" }

        await MainActor.run {
            appleRows = loadedRows.sorted { $0.day < $1.day }
            workoutCount = appleWorkouts.count
            series = fetched
            rebuildWindowCache()
            loaded = true
        }
    }

    // MARK: - Range control + header span

    private var rangeControl: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                SegmentedPillControl(RangeWindow.allCases, selection: $range) { $0.label }
                Spacer()
                Text(range.caption).strandOverline()
            }
            Text(rangeSummaryCaption)
                .font(StrandFont.footnote)
                .foregroundStyle(StrandPalette.textTertiary)
                .accessibilityLabel(rangeSummaryCaption)
        }
    }

    /// Window-level caption near the control: how many days the per-day rows span in
    /// the selected range, plus a flag if any tracked series had to auto-widen.
    private var rangeSummaryCaption: String {
        let n = windowedRows.count
        let unit = n == 1 ? "day" : "days"
        let anyWidened = Self.seriesKeys.contains { !raw($0).isEmpty && effectiveRange($0) != range }
        let base = "\(n) \(unit) · \(range.name)"
        return anyWidened ? base + " · some sparse series widened" : base
    }

    /// Header subtitle reflects the windowed (visible) per-day span.
    private var spanSubtitle: String? {
        let rows = loaded ? windowedRows : appleRows
        guard let first = rows.first?.day, let last = rows.last?.day,
              let lo = date(first), let hi = date(last) else {
            return "Steps, heart, sleep, body composition and VO₂ max — read locally on this Mac."
        }
        let loS = Self.spanFormatter.string(from: lo)
        let hiS = Self.spanFormatter.string(from: hi)
        let span = loS == hiS ? loS : "\(loS) → \(hiS)"
        return "\(rows.count) days · \(span)"
    }

    /// AppleDaily rows trimmed to the active window (for the span readout), taken
    /// RELATIVE TO THE LATEST recorded day rather than "now". Served from the
    /// per-render cache; recomputed only when `appleRows`/`range` change.
    private var windowedRows: [AppleDaily] {
        loaded ? windowedRowsCache : computeWindowedRows()
    }

    /// The actual windowing of the per-day rows. Called only from
    /// rebuildWindowCache and the not-yet-loaded fallback — never per render.
    private func computeWindowedRows() -> [AppleDaily] {
        guard let n = range.days else { return appleRows }
        guard let lastDay = appleRows.last?.day, let last = date(lastDay) else { return [] }
        let cutoff = last.addingTimeInterval(-Double(n - 1) * 86_400)
        return appleRows.filter { row in
            guard let d = date(row.day) else { return false }
            return d >= cutoff
        }
    }

    private var loadingState: some View {
        NoopCard {
            HStack(spacing: 10) {
                ProgressView().controlSize(.small)
                Text("Reading your Apple Health history…")
                    .font(StrandFont.subhead).foregroundStyle(StrandPalette.textSecondary)
            }
        }
    }

    // MARK: - Metric tiles (uniform 104pt StatTiles in an adaptive grid)

    private var tileGrid: some View {
        LazyVGrid(
            columns: [GridItem(.adaptive(minimum: 168), spacing: NoopMetrics.gap)],
            alignment: .leading,
            spacing: NoopMetrics.gap
        ) {
            statTile(key: "steps", label: "Steps",
                     accent: StrandPalette.metricCyan, fmt: { intString($0) })
            statTile(key: "resting_hr", label: "Resting HR",
                     accent: StrandPalette.metricRose, unit: "bpm",
                     fmt: { "\(Int($0.rounded()))" })
            statTile(key: "hrv", label: "HRV",
                     accent: StrandPalette.metricPurple, unit: "ms",
                     fmt: { "\(Int($0.rounded()))" })
            statTile(key: "vo2max", label: "VO₂ Max",
                     accent: StrandPalette.accent, unit: "ml/kg",
                     fmt: { String(format: "%.1f", $0) })
            statTile(key: "weight", label: "Weight",
                     accent: StrandPalette.accent, unit: "kg",
                     fmt: { String(format: "%.1f", $0) })
            statTile(key: "body_fat", label: "Body Fat",
                     accent: StrandPalette.metricAmber, unit: "%",
                     fmt: { String(format: "%.1f", $0) })
            statTile(key: "lean_mass", label: "Lean Mass",
                     accent: StrandPalette.accent, unit: "kg",
                     fmt: { String(format: "%.1f", $0) })
            statTile(key: "asleep_min", label: "Asleep avg",
                     accent: StrandPalette.metricPurple,
                     aggregate: .mean, fmt: { durationString($0) })
            workoutsTile
        }
    }

    /// How a tile's hero value is derived from its window.
    private enum Aggregate { case latest, mean }

    /// A StatTile for one metric. Sparse-safe: the window auto-falls-back to ALL,
    /// the hero is the LATEST point ("as of <date>") unless a mean is requested,
    /// and the sparkline + caption track the same resolved window.
    private func statTile(key: String, label: String,
                          accent: Color, unit: String = "",
                          aggregate: Aggregate = .latest,
                          fmt: @escaping (Double) -> String) -> some View {
        let rows = resolvedWindow(key)
        let values = rows.map(\.value)
        let value: String
        let caption: String?
        if values.isEmpty {
            value = "—"
            caption = nil
        } else {
            switch aggregate {
            case .latest:
                let v = values.last ?? 0
                value = unit.isEmpty ? fmt(v) : "\(fmt(v)) \(unit)"
                caption = rows.last.flatMap { date($0.day) }.map { "as of \(Self.asOfFormatter.string(from: $0))" }
            case .mean:
                let m = mean(values) ?? 0
                value = unit.isEmpty ? fmt(m) : "\(fmt(m)) \(unit)"
                caption = "avg · \(values.count)d"
            }
        }
        return StatTile(
            label: label,
            value: value,
            caption: caption,
            accent: values.isEmpty ? StrandPalette.textTertiary : accent,
            sparkline: values.count > 1 ? sparkValues(values) : nil,
            sparkColor: accent
        )
    }

    /// Workouts is a count, not a series — its own fixed-height StatTile.
    private var workoutsTile: some View {
        StatTile(
            label: "Workouts",
            value: "\(workoutCount)",
            caption: workoutCount > 0 ? "Apple-logged" : nil,
            accent: workoutCount > 0 ? StrandPalette.strainColor(12) : StrandPalette.textTertiary
        )
    }

    // MARK: - Chart sections (uniform ChartCard, same height per page)

    private var heartSection: some View {
        VStack(alignment: .leading, spacing: NoopMetrics.gap) {
            SectionHeader("Heart & Vitals", overline: "Cardiac",
                          trailing: range.caption)
            chartCard(title: "Resting heart rate", key: "resting_hr",
                      gradient: roseGradient, fallback: 40...80,
                      fmt: { "\(Int($0.rounded())) bpm" })
            chartCard(title: "Heart rate variability", key: "hrv",
                      gradient: purpleGradient, fallback: 20...120,
                      fmt: { "\(Int($0.rounded())) ms" })
            chartCard(title: "Blood oxygen", key: "spo2",
                      gradient: cyanGradient, fallback: 90...100,
                      fmt: { String(format: "%.1f%%", $0) })
            chartCard(title: "Respiratory rate", key: "resp_rate",
                      gradient: accentGradient, fallback: 10...22,
                      fmt: { String(format: "%.1f rpm", $0) })
        }
    }

    private var activitySection: some View {
        VStack(alignment: .leading, spacing: NoopMetrics.gap) {
            SectionHeader("Activity & Energy", overline: "Movement",
                          trailing: range.caption)
            chartCard(title: "Steps", key: "steps",
                      gradient: cyanGradient, fallback: 0...12000,
                      fmt: { intString($0) })
            chartCard(title: "Active energy", key: "active_kcal",
                      gradient: amberGradient, fallback: 0...1000,
                      fmt: { "\(intString($0)) kcal" })
        }
    }

    private var bodySection: some View {
        VStack(alignment: .leading, spacing: NoopMetrics.gap) {
            SectionHeader("Body Composition", overline: "Slow threads",
                          trailing: range.caption)
            chartCard(title: "Weight", key: "weight",
                      gradient: accentGradient, fallback: 50...100,
                      fmt: { String(format: "%.1f kg", $0) })
            chartCard(title: "Body fat", key: "body_fat",
                      gradient: amberGradient, fallback: 8...35,
                      fmt: { String(format: "%.1f%%", $0) })
            chartCard(title: "Lean body mass", key: "lean_mass",
                      gradient: accentGradient, fallback: 40...80,
                      fmt: { String(format: "%.1f kg", $0) })
            chartCard(title: "BMI", key: "bmi",
                      gradient: purpleGradient, fallback: 16...35,
                      fmt: { String(format: "%.1f", $0) })
        }
    }

    private var sleepSection: some View {
        VStack(alignment: .leading, spacing: NoopMetrics.gap) {
            SectionHeader("Sleep", overline: "Rest",
                          trailing: range.caption)
            chartCard(title: "Asleep", key: "asleep_min",
                      gradient: purpleGradient, fallback: 240...600,
                      fmt: { durationString($0) })
        }
    }

    /// One uniform ChartCard for a metric series: header + TrendChart body (same
    /// height) + avg/min/max ChartFooter. Sparse-safe via resolvedWindow.
    @ViewBuilder
    private func chartCard(title: String, key: String, gradient: Gradient,
                           fallback: ClosedRange<Double>,
                           fmt: @escaping (Double) -> String) -> some View {
        let rows = resolvedWindow(key)
        let pts = trendPoints(rows)
        let vals = rows.map(\.value)
        let trailing = mean(vals).map { fmt($0) }
        // One concrete footer type (ChartFooter) keeps every card uniform — avg /
        // min / max / point-count, with dashes only in the defensive no-data case.
        let footerItems: [(String, String)] = {
            guard let avg = mean(vals), let lo = vals.min(), let hi = vals.max() else {
                return [("Avg", "—"), ("Min", "—"), ("Max", "—"), ("Points", "0")]
            }
            return [("Avg", fmt(avg)), ("Min", fmt(lo)), ("Max", fmt(hi)), ("Points", "\(vals.count)")]
        }()
        ChartCard(
            title: title,
            subtitle: rangeNote(forKey: key),
            trailing: trailing,
            chart: {
                if pts.count >= 2 {
                    TrendChart(
                        points: pts,
                        gradient: gradient,
                        valueRange: valueRange(pts, fallback: fallback),
                        showsArea: true,
                        height: NoopMetrics.chartHeight,
                        valueFormat: fmt
                    )
                } else if let only = vals.last {
                    // A single point is not a line — present the lone reading,
                    // never an "empty" state when the series has data.
                    singlePoint(only, fmt: fmt, accent: StrandPalette.sample(stops: gradient.stops, at: 0.85))
                } else {
                    emptyChart
                }
            },
            footer: { ChartFooter(footerItems) }
        )
    }

    /// Lone-reading body for series with exactly one point in range.
    private func singlePoint(_ value: Double, fmt: (Double) -> String, accent: Color) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Latest reading").strandOverline()
            Text(fmt(value)).font(StrandFont.number(34)).foregroundStyle(accent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }

    private var emptyChart: some View {
        Text("No readings recorded.")
            .font(StrandFont.subhead)
            .foregroundStyle(StrandPalette.textTertiary)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
    }

    // MARK: - Per-metric gradients (colour communicates category only)

    private var accentGradient: Gradient {
        Gradient(colors: [StrandPalette.accentMuted, StrandPalette.accent, StrandPalette.accentHover])
    }
    private var roseGradient: Gradient {
        Gradient(colors: [StrandPalette.statusWarning, StrandPalette.statusCritical])
    }
    private var cyanGradient: Gradient {
        Gradient(colors: [StrandPalette.metricCyan.opacity(0.55), StrandPalette.metricCyan])
    }
    private var amberGradient: Gradient {
        Gradient(colors: [StrandPalette.metricAmber.opacity(0.55), StrandPalette.metricAmber])
    }
    private var purpleGradient: Gradient {
        Gradient(colors: [StrandPalette.metricPurple.opacity(0.55), StrandPalette.metricPurple])
    }

    // MARK: - Series helpers (sparse-data fallback to ALL)

    /// All-history rows for a key (ascending by day).
    private func raw(_ key: String) -> [(day: String, value: Double)] { series[key] ?? [] }

    /// The latest recorded day for a key (anchors its windows).
    private func latestDate(_ key: String) -> Date? {
        guard let d = raw(key).last?.day else { return nil }
        return date(d)
    }

    /// Rows for a key over a given range, taken RELATIVE TO THE LATEST data point
    /// (not "now"); `.all` returns everything.
    private func slice(_ key: String, _ r: RangeWindow) -> [(day: String, value: Double)] {
        let all = raw(key)
        guard let n = r.days else { return all }
        guard let last = latestDate(key) else { return [] }
        let cutoff = last.addingTimeInterval(-Double(n - 1) * 86_400)
        return all.filter { row in
            guard let d = date(row.day) else { return false }
            return d >= cutoff
        }
    }

    /// The range actually shown for a key: the SELECTED range whenever its window
    /// holds ≥1 point, otherwise the smallest LARGER range that does — so switching
    /// ranges stays visibly distinct and only sparse windows widen. Served from the
    /// per-render cache; falls back to a fresh compute on a cache miss.
    private func effectiveRange(_ key: String) -> RangeWindow {
        windowCache[key]?.effective ?? computeEffectiveRange(key)
    }

    /// The actual effective-range computation (re-slices the series, once per widening
    /// candidate). Called only from rebuildWindowCache and the cache-miss fallback —
    /// never repeatedly within a single render.
    private func computeEffectiveRange(_ key: String) -> RangeWindow {
        guard !raw(key).isEmpty else { return range }
        for r in range.widening where !slice(key, r).isEmpty { return r }
        return .all
    }

    /// Rows for a key trimmed to its resolved (possibly widened) window. Served from
    /// the per-render cache; falls back to a fresh compute on a cache miss.
    private func resolvedWindow(_ key: String) -> [(day: String, value: Double)] {
        if let cached = windowCache[key]?.rows { return cached }
        return slice(key, computeEffectiveRange(key))
    }

    /// Card subtitle: "N readings · <range>", flagging an auto-widen when it happened.
    private func rangeNote(forKey key: String) -> String {
        let rows = resolvedWindow(key)
        let eff = effectiveRange(key)
        let n = rows.count
        let unit = n == 1 ? "reading" : "readings"
        if eff != range {
            return "\(n) \(unit) · sparse — widened to \(eff.name)"
        }
        return "\(n) \(unit) · \(range.name)"
    }

    private func trendPoints(_ rows: [(day: String, value: Double)]) -> [TrendPoint] {
        rows.compactMap { row in
            guard let dt = date(row.day) else { return nil }
            return TrendPoint(date: dt, value: row.value)
        }
    }

    /// Sparklines need a non-degenerate series; cap to the last ~40 samples.
    private func sparkValues(_ values: [Double]) -> [Double] {
        guard values.count > 1 else { return [values.first ?? 0, values.first ?? 0] }
        return Array(values.suffix(40))
    }

    private func mean(_ values: [Double]) -> Double? {
        guard !values.isEmpty else { return nil }
        return values.reduce(0, +) / Double(values.count)
    }

    private func valueRange(_ pts: [TrendPoint], fallback: ClosedRange<Double>, pad: Double = 0.12) -> ClosedRange<Double> {
        let v = pts.map(\.value)
        guard let lo = v.min(), let hi = v.max() else { return fallback }
        if hi <= lo { return (lo - 1)...(hi + 1) }
        let span = hi - lo
        return (lo - span * pad)...(hi + span * pad)
    }

    private func intString(_ v: Double) -> String {
        let n = Int(v.rounded())
        if abs(n) >= 1000 {
            let f = NumberFormatter()
            f.numberStyle = .decimal
            f.maximumFractionDigits = 0
            return f.string(from: NSNumber(value: n)) ?? "\(n)"
        }
        return "\(n)"
    }

    private func durationString(_ minutes: Double) -> String {
        let total = Int(minutes.rounded())
        let h = total / 60, m = total % 60
        return h > 0 ? "\(h)h \(m)m" : "\(m)m"
    }
}

// MARK: - Preview seam

extension AppleHealthView {
    /// In-memory bundle that bypasses the store-backed async load for previews.
    fileprivate struct PreviewData {
        var rows: [AppleDaily]
        var workoutCount: Int
        var series: [String: [(day: String, value: Double)]]
    }
}

#if DEBUG
@MainActor
private func appleHealthPreviewData() -> AppleHealthView.PreviewData {
    let cal = Calendar(identifier: .gregorian)
    let fmt = DateFormatter()
    fmt.locale = Locale(identifier: "en_US_POSIX")
    fmt.timeZone = TimeZone(identifier: "UTC")
    fmt.dateFormat = "yyyy-MM-dd"
    let today = Date()

    var rows: [AppleDaily] = []
    var series: [String: [(day: String, value: Double)]] = [
        "steps": [], "active_kcal": [], "vo2max": [],
        "resting_hr": [], "hrv": [], "spo2": [], "resp_rate": [], "asleep_min": [],
        "weight": [], "body_fat": [], "lean_mass": [], "bmi": []
    ]

    // Seed ~2 years so the range control has real depth to window into.
    for i in stride(from: 729, through: 0, by: -1) {
        guard let d = cal.date(byAdding: .day, value: -i, to: today) else { continue }
        let day = fmt.string(from: d)
        let phase = Double(729 - i)
        let steps  = 8000 + 3200 * sin(phase / 6.0) + Double((Int(phase) * 53) % 1800)
        let active = 420 + 180 * sin(phase / 5.0 + 0.6) + Double((Int(phase) * 17) % 90)
        let rhr    = 53 + 4 * sin(phase / 8.0) + Double((Int(phase) * 7) % 4) - 2
        let hrv    = 58 + 16 * sin(phase / 9.0) + Double((Int(phase) * 13) % 11) - 5
        let spo2   = 96 + 1.4 * sin(phase / 4.0) + Double((Int(phase) * 3) % 2)
        let resp   = 14.5 + 1.2 * sin(phase / 7.0)
        let vo2    = 47 + 2.2 * sin(phase / 21.0)
        let asleep = 410 + 55 * sin(phase / 5.0 + 1.1) + Double((Int(phase) * 11) % 30) - 15
        // Slow body-composition drift over the two years (measured WEEKLY → sparse).
        let weight = 78.0 - 5.0 * sin(phase / 220.0) + 0.6 * sin(phase / 13.0)
        let bodyFat = 18.0 - 3.0 * sin(phase / 240.0) + 0.4 * sin(phase / 11.0)
        let lean   = weight * (1.0 - bodyFat / 100.0)
        let bmi    = weight / (1.78 * 1.78)

        rows.append(AppleDaily(
            day: day,
            steps: Int(steps.rounded()),
            activeKcal: max(120, active),
            basalKcal: 1600,
            vo2max: vo2,
            avgHr: 72,
            maxHr: 148,
            walkingHr: 96,
            weightKg: weight))

        series["steps"]?.append((day, max(0, steps)))
        series["active_kcal"]?.append((day, max(80, active)))
        series["vo2max"]?.append((day, vo2))
        series["resting_hr"]?.append((day, max(40, rhr)))
        series["hrv"]?.append((day, max(15, hrv)))
        series["spo2"]?.append((day, min(100, spo2)))
        series["resp_rate"]?.append((day, resp))
        series["asleep_min"]?.append((day, max(180, asleep)))
        // Body composition is logged once a week → deliberately sparse, to exercise
        // the trailing-window → ALL fallback (a W/M view would otherwise be empty).
        if Int(phase) % 7 == 0 {
            series["weight"]?.append((day, weight))
            series["body_fat"]?.append((day, bodyFat))
            series["lean_mass"]?.append((day, lean))
            series["bmi"]?.append((day, bmi))
        }
    }

    return .init(rows: rows, workoutCount: 124, series: series)
}

#Preview("Apple Health — seeded") {
    AppleHealthView(previewData: appleHealthPreviewData())
        .environmentObject(Repository(deviceId: "preview"))
        .frame(width: 920, height: 980)
        .preferredColorScheme(.dark)
}

#Preview("Apple Health — empty") {
    AppleHealthView(previewData: .init(rows: [], workoutCount: 0, series: [:]))
        .environmentObject(Repository(deviceId: "preview"))
        .frame(width: 920, height: 600)
        .preferredColorScheme(.dark)
}
#endif
