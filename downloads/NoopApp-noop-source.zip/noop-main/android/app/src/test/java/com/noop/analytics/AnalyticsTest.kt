package com.noop.analytics

import com.noop.data.DailyMetric
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AnalyticsTest {

    // --- Hrv.rmssd ----------------------------------------------------------

    @Test
    fun rmssd_knownVector() {
        // rr = [800, 810, 790, 805, 795]
        // diffs = [10, -20, 15, -10] -> squares = [100, 400, 225, 100]
        // sum = 825, n = 4, mean = 206.25, sqrt(206.25) = 14.361406616...
        val rr = listOf(800, 810, 790, 805, 795)
        assertEquals(14.361406616, Hrv.rmssd(rr), 1e-6)
    }

    @Test
    fun rmssd_constantIntervalsIsZero() {
        assertEquals(0.0, Hrv.rmssd(listOf(1000, 1000, 1000)), 1e-12)
    }

    @Test
    fun rmssd_tooFewSamplesIsZero() {
        assertEquals(0.0, Hrv.rmssd(emptyList()), 1e-12)
        assertEquals(0.0, Hrv.rmssd(listOf(1000)), 1e-12)
    }

    @Test
    fun rmssd_twoSamples() {
        // diff = 50 -> square = 2500 -> mean = 2500 -> sqrt = 50
        assertEquals(50.0, Hrv.rmssd(listOf(900, 950)), 1e-9)
    }

    // --- Zones --------------------------------------------------------------

    @Test
    fun zone_ladder() {
        val max = 190
        assertEquals(5, Zones.zone((max * 0.95).toInt(), max))  // 180 -> 0.947 -> z5
        assertEquals(4, Zones.zone((max * 0.82).toInt(), max))  // 155 -> 0.815 -> z4
        assertEquals(3, Zones.zone((max * 0.72).toInt(), max))  // 136 -> 0.715 -> z3
        assertEquals(2, Zones.zone((max * 0.62).toInt(), max))  // 117 -> 0.615 -> z2
        assertEquals(1, Zones.zone((max * 0.50).toInt(), max))  // 95  -> 0.5   -> z1
    }

    @Test
    fun zone_exactBoundaries() {
        // hrMax = 100 makes pct == hr/100 exactly.
        assertEquals(5, Zones.zone(90, 100))
        assertEquals(4, Zones.zone(80, 100))
        assertEquals(3, Zones.zone(70, 100))
        assertEquals(2, Zones.zone(60, 100))
        assertEquals(1, Zones.zone(59, 100))
    }

    @Test
    fun zone_invalidMaxFallsBackToZoneOne() {
        assertEquals(1, Zones.zone(120, 0))
        assertEquals(1, Zones.zone(120, -10))
    }

    @Test
    fun hrMaxTanaka_roundsCorrectly() {
        // 208 - 0.7*30 = 187.0 -> 187
        assertEquals(187, Zones.hrMaxTanaka(30))
        // 208 - 0.7*25 = 190.5 -> 191 (round half up)
        assertEquals(191, Zones.hrMaxTanaka(25))
        // 208 - 0.7*45 = 176.5 -> 177
        assertEquals(177, Zones.hrMaxTanaka(45))
    }

    // --- IllnessWatch -------------------------------------------------------

    private fun day(
        d: String,
        restingHr: Int? = null,
        avgHrv: Double? = null,
        skinTempDevC: Double? = null,
        respRateBpm: Double? = null,
    ): DailyMetric = DailyMetric(
        deviceId = "test",
        day = d,
        restingHr = restingHr,
        avgHrv = avgHrv,
        skinTempDevC = skinTempDevC,
        respRateBpm = respRateBpm,
    )

    @Test
    fun illness_tooFewDaysReturnsNull() {
        val days = (0 until 10).map { day("2026-01-%02d".format(it + 1), restingHr = 50, avgHrv = 60.0) }
        assertNull(IllnessWatch.evaluate(days))
    }

    @Test
    fun illness_clearBaselineReturnsNull() {
        // 31 stable days: recent == baseline, no anomalies.
        val days = (0 until 31).map {
            day("2026-01-%02d".format(it + 1), restingHr = 50, avgHrv = 60.0, skinTempDevC = 0.0, respRateBpm = 14.0)
        }
        assertNull(IllnessWatch.evaluate(days))
    }

    @Test
    fun illness_twoFlagsRaisesBanner() {
        // 31 calm days, then 2 strained recent days appended (33 total).
        // evaluate() uses takeLast(2) as recent and takeLast(31).dropLast(3) as baseline,
        // so the 2 strained days are "recent" and the calm days form the baseline.
        val baseline = (0 until 31).map {
            day("2026-01-%02d".format(it + 1), restingHr = 50, avgHrv = 60.0, skinTempDevC = 0.0, respRateBpm = 14.0)
        }
        val recent = listOf(
            // RHR +8, HRV -25% (45/60), skin temp +0.8 -> three flags
            day("2026-02-01", restingHr = 58, avgHrv = 45.0, skinTempDevC = 0.8, respRateBpm = 14.0),
            day("2026-02-02", restingHr = 58, avgHrv = 45.0, skinTempDevC = 0.8, respRateBpm = 14.0),
        )
        val days = baseline + recent
        val msg = IllnessWatch.evaluate(days)
        assertNotNull(msg)
        assertTrue(msg!!.contains("resting HR"))
        assertTrue(msg.contains("HRV"))
        assertTrue(msg.contains("skin temp"))
    }

    @Test
    fun illness_singleFlagReturnsNull() {
        // Only resting HR elevated in the recent 2 days -> one flag -> null.
        val baseline = (0 until 31).map {
            day("2026-01-%02d".format(it + 1), restingHr = 50, avgHrv = 60.0, skinTempDevC = 0.0, respRateBpm = 14.0)
        }
        val recent = listOf(
            day("2026-02-01", restingHr = 60, avgHrv = 60.0, skinTempDevC = 0.0, respRateBpm = 14.0),
            day("2026-02-02", restingHr = 60, avgHrv = 60.0, skinTempDevC = 0.0, respRateBpm = 14.0),
        )
        assertNull(IllnessWatch.evaluate(baseline + recent))
    }
}
